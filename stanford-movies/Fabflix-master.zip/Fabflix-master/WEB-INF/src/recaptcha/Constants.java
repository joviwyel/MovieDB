package recaptcha;

class Constants {
    public static final String SITE_KEY = "Site Key";
    public static final String SECRET_KEY = "For British Eyes Onlye";

}

